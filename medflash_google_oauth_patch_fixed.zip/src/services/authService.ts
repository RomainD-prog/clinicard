import type { User } from "@supabase/supabase-js";
import { supabase } from "./supabaseClient";
import { Platform } from "react-native";
import * as WebBrowser from "expo-web-browser";

// Needed for web (and safe on native)
WebBrowser.maybeCompleteAuthSession();

// --- Types ---
export type AuthUser = {
  id: string;
  email: string;
  createdAt: string;
  firstName: string | null;
  lastName: string | null;
};

export type SignupData = {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
};

export type LoginData = {
  email: string;
  password: string;
};

// --- Helper pour transformer l'objet User de Supabase ---
function mapUser(user: User): AuthUser {
  const md = user.user_metadata ?? {};

  return {
    id: user.id,
    email: user.email ?? "",
    createdAt: user.created_at,
    firstName: (md.firstName ?? md.first_name ?? md.given_name ?? null) as string | null,
    lastName: (md.lastName ?? md.last_name ?? md.family_name ?? null) as string | null,
  };
}

// --- Fonctions API ---

export async function signup(data: SignupData): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    const { data: signupData, error } = await supabase.auth.signUp({
      email: data.email,
      password: data.password,
      options: {
        data: {
          firstName: data.firstName,
          lastName: data.lastName,
        },
      },
    });

    if (error) return { user: null, error: error.message };

    return { 
      user: signupData.user ? mapUser(signupData.user) : null, 
      error: null 
    };
  } catch (err) {
    return { user: null, error: "Une erreur inattendue s'est produite" };
  }
}

export async function login(data: LoginData): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    const { data: loginData, error } = await supabase.auth.signInWithPassword({
      email: data.email,
      password: data.password,
    });

    if (error) return { user: null, error: error.message };

    return { 
      user: loginData.user ? mapUser(loginData.user) : null, 
      error: null 
    };
  } catch (err) {
    return { user: null, error: "Une erreur inattendue" };
  }
}


export async function signInWithGoogle(): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    // IMPORTANT:
    // - On native (dev build / production), we rely on the custom scheme declared in app.json ("scheme": "medflash").
    // - On web, Supabase will handle the full-page redirect and detectSessionInUrl=true will finalize the session.
    const redirectTo =
      Platform.OS === "web"
        ? typeof window !== "undefined"
          ? `${window.location.origin}/`
          : "/"
        : "medflash://";

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo,
        // We handle redirect ourselves (native = auth session, web = location.assign below).
        skipBrowserRedirect: true,
      },
    });

    if (error) return { user: null, error: error.message };
    if (!data?.url) return { user: null, error: "URL OAuth introuvable." };

    if (Platform.OS === "web") {
      if (typeof window !== "undefined") window.location.assign(data.url);
      return { user: null, error: null };
    }

    // Native: open an auth session and exchange the code for a Supabase session (PKCE).
    const result = await WebBrowser.openAuthSessionAsync(data.url, redirectTo);

    if (result.type !== "success" || !result.url) {
      return { user: null, error: "Connexion annulée." };
    }

    const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(result.url);
    if (exchangeError) return { user: null, error: exchangeError.message };

    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError) return { user: null, error: userError.message };

    return { user: userData.user ? mapUser(userData.user) : null, error: null };
  } catch (err: any) {
    return { user: null, error: err?.message ?? "Une erreur inattendue" };
  }
}

export async function logout(): Promise<{ error: string | null }> {
  const { error } = await supabase.auth.signOut();
  return { error: error?.message ?? null };
}

/**
 * Version corrigée de getCurrentUser
 */
export async function getCurrentUser(): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    // getUser() est plus sûr que getSession() car il valide le JWT côté serveur
    const { data: { user }, error } = await supabase.auth.getUser();
    
    if (error || !user) {
      return { user: null, error: error?.message ?? null };
    }

    return { user: mapUser(user), error: null };
  } catch (err) {
    return { user: null, error: "Impossible de récupérer l'utilisateur" };
  }
}

export async function isLoggedIn(): Promise<boolean> {
  const { data } = await supabase.auth.getSession();
  return !!data.session;
}

export async function changePassword(newPassword: string): Promise<{ error: string | null }> {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  return { error: error?.message ?? null };
}

export async function deleteAccount(): Promise<{ error: string | null }> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    const userId = session?.user.id;
    if (!userId) return { error: "Utilisateur non connecté" };

    // 1. Supprimer les données métier
    const { error: dbError } = await supabase
      .from("user_data")
      .delete()
      .eq("user_id", userId);

    if (dbError) throw dbError;

    // Note: La suppression réelle du compte Auth nécessite une fonction admin.
    // On se contente de déconnecter ici.
    await logout();
    return { error: null };
  } catch (err: any) {
    return { error: err.message || "Erreur lors de la suppression" };
  }
}
