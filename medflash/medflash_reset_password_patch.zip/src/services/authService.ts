import type { User } from "@supabase/supabase-js";
import * as Linking from "expo-linking";
import { Platform } from "react-native";
import { supabase } from "./supabaseClient";

// --- Types ---
export type AuthUser = {
  id: string;
  email: string;
  createdAt: string;
  firstName: string | null;
  lastName: string | null;
};

export type SignupData = {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
};

export type LoginData = {
  email: string;
  password: string;
};

// --- Helper pour transformer l'objet User de Supabase ---
function mapUser(user: User): AuthUser {
  const md = user.user_metadata ?? {};

  return {
    id: user.id,
    email: user.email ?? "",
    createdAt: user.created_at,
    firstName: (md.firstName ?? md.first_name ?? md.given_name ?? null) as string | null,
    lastName: (md.lastName ?? md.last_name ?? md.family_name ?? null) as string | null,
  };
}

// --- Fonctions API ---

export async function signup(data: SignupData): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    const { data: signupData, error } = await supabase.auth.signUp({
      email: data.email,
      password: data.password,
      options: {
        data: {
          firstName: data.firstName,
          lastName: data.lastName,
        },
      },
    });

    if (error) return { user: null, error: error.message };

    return { 
      user: signupData.user ? mapUser(signupData.user) : null, 
      error: null 
    };
  } catch (err) {
    return { user: null, error: "Une erreur inattendue s'est produite" };
  }
}

export async function login(data: LoginData): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    const { data: loginData, error } = await supabase.auth.signInWithPassword({
      email: data.email,
      password: data.password,
    });

    if (error) return { user: null, error: error.message };

    return { 
      user: loginData.user ? mapUser(loginData.user) : null, 
      error: null 
    };
  } catch (err) {
    return { user: null, error: "Une erreur inattendue" };
  }
}

export async function logout(): Promise<{ error: string | null }> {
  const { error } = await supabase.auth.signOut();
  return { error: error?.message ?? null };
}

/**
 * --- Mot de passe oublié / reset password ---
 *
 * Flow :
 * 1) requestPasswordReset(email) => Supabase envoie un email "recovery".
 * 2) L'utilisateur ouvre le lien depuis l'email, qui redirige vers l'app via deep link.
 * 3) Dans l'écran /auth/reset, on appelle completePasswordRecoveryFromUrl(url)
 *    puis on demande le nouveau mot de passe et on fait updatePassword(newPassword).
 */

function getNativeRedirectTo(): string {
  // expo-router + expo-linking :
  // - En dev dans Expo Go: exp://.../--/auth/reset
  // - En dev build / prod: medflash://auth/reset (via scheme app.json)
  return Linking.createURL("auth/reset");
}

function parseUrlParams(url: string): Record<string, string> {
  // Supabase peut renvoyer des paramètres dans le hash (#) ou la query (?)
  const idxHash = url.indexOf("#");
  const idxQ = url.indexOf("?");
  const raw = idxHash >= 0 ? url.slice(idxHash + 1) : idxQ >= 0 ? url.slice(idxQ + 1) : "";
  const out: Record<string, string> = {};
  for (const part of raw.split("&")) {
    if (!part) continue;
    const [k, v] = part.split("=");
    if (!k) continue;
    out[decodeURIComponent(k)] = decodeURIComponent(v ?? "");
  }
  return out;
}

export async function requestPasswordReset(email: string): Promise<{ error: string | null }> {
  try {
    const redirectTo = getNativeRedirectTo();
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo,
    });
    return { error: error?.message ?? null };
  } catch (e: any) {
    return { error: e?.message ?? "Impossible d'envoyer l'email de réinitialisation." };
  }
}

/**
 * Finalise une session "recovery" à partir de l'URL ouverte depuis l'email.
 * - Si on a un code (PKCE) => exchangeCodeForSession(url)
 * - Sinon (implicit) => setSession({ access_token, refresh_token })
 */
export async function completePasswordRecoveryFromUrl(url: string): Promise<{ error: string | null }> {
  try {
    const params = parseUrlParams(url);

    // PKCE code flow
    if (params.code) {
      const { error } = await supabase.auth.exchangeCodeForSession(url);
      return { error: error?.message ?? null };
    }

    // Implicit flow (access_token / refresh_token)
    const access_token = params.access_token;
    const refresh_token = params.refresh_token;
    if (access_token && refresh_token) {
      const { error } = await supabase.auth.setSession({ access_token, refresh_token });
      return { error: error?.message ?? null };
    }

    // Quand Supabase est configuré avec "Site URL" exemple.com, il peut arriver que
    // le navigateur ouvre une page (ex: example.com) sans params utilisables.
    // Dans ce cas, on ne peut pas finaliser le recovery.
    return { error: "Lien de récupération invalide ou incomplet." };
  } catch (e: any) {
    return { error: e?.message ?? "Impossible de finaliser la récupération." };
  }
}

export async function updatePassword(newPassword: string): Promise<{ error: string | null }> {
  try {
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    return { error: error?.message ?? null };
  } catch (e: any) {
    return { error: e?.message ?? "Impossible de mettre à jour le mot de passe." };
  }
}

/**
 * --- Mot de passe oublié / reset password ---
 *
 * Flow :
 * 1) requestPasswordReset(email) => Supabase envoie un email "recovery".
 * 2) L'utilisateur ouvre le lien => deep link vers `auth/reset`.
 * 3) L'écran `app/auth/reset.tsx` appelle `setSessionFromUrl(url)` puis `updatePassword(newPassword)`.
 */

function getResetRedirectUrl() {
  // expo-linking génère :
  // - Expo Go: exp://.../--/auth/reset
  // - Dev build / prod: medflash://auth/reset (car scheme = medflash)
  return Linking.createURL("auth/reset");
}

export async function requestPasswordReset(email: string): Promise<{ error: string | null }> {
  try {
    const redirectTo = getResetRedirectUrl();

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo,
    });

    return { error: error?.message ?? null };
  } catch (e: any) {
    return { error: e?.message ?? "Impossible d'envoyer l'email de réinitialisation." };
  }
}

function parseUrlParams(url: string): Record<string, string> {
  // Supabase peut renvoyer les params dans le hash (#) ou la query (?)
  const hashIndex = url.indexOf("#");
  const queryIndex = url.indexOf("?");
  const raw = hashIndex >= 0 ? url.slice(hashIndex + 1) : queryIndex >= 0 ? url.slice(queryIndex + 1) : "";
  const params = new URLSearchParams(raw);
  const out: Record<string, string> = {};
  params.forEach((v, k) => {
    out[k] = v;
  });
  return out;
}

/**
 * Finalise une session Supabase à partir d'une URL de deep link reçue après un flow auth.
 * - Si `code` (PKCE) est présent => exchangeCodeForSession(url)
 * - Sinon si `access_token` et `refresh_token` => setSession
 */
export async function setSessionFromUrl(url: string): Promise<{ error: string | null }> {
  try {
    const p = parseUrlParams(url);

    if (p.code) {
      const { error } = await supabase.auth.exchangeCodeForSession(url);
      return { error: error?.message ?? null };
    }

    if (p.access_token && p.refresh_token) {
      const { error } = await supabase.auth.setSession({
        access_token: p.access_token,
        refresh_token: p.refresh_token,
      });
      return { error: error?.message ?? null };
    }

    // Certains liens contiennent juste `type=recovery` sans tokens quand la config est mauvaise
    return { error: "Lien invalide (tokens manquants). Vérifie les Redirect URLs dans Supabase." };
  } catch (e: any) {
    return { error: e?.message ?? "Impossible de finaliser la session." };
  }
}

export async function updatePassword(newPassword: string): Promise<{ error: string | null }> {
  try {
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    return { error: error?.message ?? null };
  } catch (e: any) {
    return { error: e?.message ?? "Impossible de changer le mot de passe." };
  }
}

/**
 * Version corrigée de getCurrentUser
 */
export async function getCurrentUser(): Promise<{ user: AuthUser | null; error: string | null }> {
  try {
    // getUser() est plus sûr que getSession() car il valide le JWT côté serveur
    const { data: { user }, error } = await supabase.auth.getUser();
    
    if (error || !user) {
      return { user: null, error: error?.message ?? null };
    }

    return { user: mapUser(user), error: null };
  } catch (err) {
    return { user: null, error: "Impossible de récupérer l'utilisateur" };
  }
}

export async function isLoggedIn(): Promise<boolean> {
  const { data } = await supabase.auth.getSession();
  return !!data.session;
}

export async function changePassword(newPassword: string): Promise<{ error: string | null }> {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  return { error: error?.message ?? null };
}

export async function deleteAccount(): Promise<{ error: string | null }> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    const userId = session?.user.id;
    if (!userId) return { error: "Utilisateur non connecté" };

    // 1. Supprimer les données métier
    const { error: dbError } = await supabase
      .from("user_data")
      .delete()
      .eq("user_id", userId);

    if (dbError) throw dbError;

    // Note: La suppression réelle du compte Auth nécessite une fonction admin.
    // On se contente de déconnecter ici.
    await logout();
    return { error: null };
  } catch (err: any) {
    return { error: err.message || "Erreur lors de la suppression" };
  }
}

// -----------------------------------------------------------------------------
// Mot de passe oublié / Reset password (via email)
// -----------------------------------------------------------------------------

/**
 * URL de retour utilisée dans les emails Supabase.
 *
 * - En dev avec Expo Go, ça génère un lien `exp://.../--/auth/reset`.
 * - En build (dev-build / production) avec `scheme: "medflash"`, ça génère
 *   `medflash://auth/reset`.
 */
export function getResetRedirectTo(): string {
  return Linking.createURL("auth/reset");
}

/**
 * Demande un email de réinitialisation.
 */
export async function requestPasswordReset(email: string): Promise<{ error: string | null }> {
  try {
    const redirectTo = getResetRedirectTo();
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo });
    return { error: error?.message ?? null };
  } catch (e: any) {
    return { error: e?.message ?? "Impossible d'envoyer l'email" };
  }
}

/**
 * Supabase (recovery / oauth) peut renvoyer soit un `code=...` (PKCE), soit
 * directement des tokens `access_token` / `refresh_token` dans le hash.
 *
 * On prend l'URL complète reçue par le deep link et on initialise la session.
 */
export async function setSessionFromRedirectUrl(url: string): Promise<{ error: string | null }> {
  try {
    if (!url) return { error: "URL manquante" };

    // 1) PKCE: ?code=... ou #code=...
    if (url.includes("code=")) {
      const { error } = await supabase.auth.exchangeCodeForSession(url);
      return { error: error?.message ?? null };
    }

    // 2) Implicit: #access_token=...&refresh_token=...
    const hash = url.split("#")[1] ?? "";
    const query = url.split("?")[1] ?? "";
    const paramsStr = hash || query;
    const params = new URLSearchParams(paramsStr);
    const access_token = params.get("access_token");
    const refresh_token = params.get("refresh_token");

    if (access_token && refresh_token) {
      const { error } = await supabase.auth.setSession({ access_token, refresh_token });
      return { error: error?.message ?? null };
    }

    return { error: "Lien invalide (tokens manquants)." };
  } catch (e: any) {
    return { error: e?.message ?? "Impossible d'initialiser la session" };
  }
}

/**
 * Une fois la session "recovery" initialisée, on peut définir un nouveau mot de passe.
 */
export async function updatePasswordFromRecovery(newPassword: string): Promise<{ error: string | null }> {
  try {
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    return { error: error?.message ?? null };
  } catch (e: any) {
    return { error: e?.message ?? "Impossible de modifier le mot de passe" };
  }
}