import { Stack } from "expo-router";
import React, { useEffect } from "react";

import { useAppStore } from "../src/store/useAppStore";
import { useStitchTheme } from "../src/uiStitch/theme";

/**
 * Root layout required by expo-router.
 *
 * The app bootstrap (loading persisted settings, decks, etc.) is triggered here.
 * If this file is missing, `isReady` will never become true and the app will
 * remain on the "Chargement..." screen.
 */
export default function RootLayout() {
  const t = useStitchTheme();
  const bootstrap = useAppStore((s: any) => s.bootstrap);

  useEffect(() => {
    let alive = true;

    (async () => {
      try {
        await bootstrap();
      } catch (e) {
        console.warn("[RootLayout] bootstrap failed:", e);
        // Fallback: avoid an infinite loading screen if bootstrap fails.
        if (alive) useAppStore.setState({ isReady: true } as any);
      }
    })();

    return () => {
      alive = false;
    };
  }, [bootstrap]);

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: t.bg },
      }}
    />
  );
}
