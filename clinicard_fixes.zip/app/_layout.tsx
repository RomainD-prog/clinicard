import { Lexend_300Light, Lexend_400Regular, Lexend_500Medium, Lexend_600SemiBold, Lexend_700Bold, useFonts } from "@expo-google-fonts/lexend";
import { Stack } from "expo-router";
import React, { useEffect, useRef } from "react";
import { View } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { LoadingBlock } from "../src/components/LoadingBlock";
import { initPurchases } from "../src/services/purchases";
import { useAppStore } from "../src/store/useAppStore";

export default function RootLayout() {
  const { isReady, bootstrap, userId, refreshSubscriptionStatus } = useAppStore();
  const lastPurchasesUserIdRef = useRef<string | null>(null);

  const [fontsLoaded] = useFonts({
    Lexend_300Light,
    Lexend_400Regular,
    Lexend_500Medium,
    Lexend_600SemiBold,
    Lexend_700Bold,
  });

  // Bootstrap global de l'app (store + stockage local + auth).
  useEffect(() => {
    bootstrap();
  }, [bootstrap]);

  // Initialise RevenueCat uniquement quand on a un userId stable.
  useEffect(() => {
    if (!isReady || !userId) return;
    if (lastPurchasesUserIdRef.current === userId) return;

    lastPurchasesUserIdRef.current = userId;

    (async () => {
      try {
        await initPurchases(userId);
        await refreshSubscriptionStatus();
      } catch (e) {
        console.warn("[RootLayout] Purchases init failed:", e);
      }
    })();
  }, [isReady, userId, refreshSubscriptionStatus]);

  if (!isReady || !fontsLoaded) {
    return (
      <View style={{ padding: 20, marginTop: 40 }}>
        <LoadingBlock label="Initialisation…" />
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <Stack
          screenOptions={{
            headerShown: false,
            headerTitleStyle: { fontFamily: "Lexend_700Bold" },
            headerBackTitle: "Retour",
          }}
        >
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
          <Stack.Screen name="import/index" options={{ headerShown: false }} />
          <Stack.Screen name="import/options" options={{ headerShown: false }} />
          <Stack.Screen name="job/[jobId]" options={{ headerShown: true, title: "Génération" }} />
          <Stack.Screen name="deck/[deckId]" options={{ headerShown: false }} />
          <Stack.Screen name="deck/[deckId]/quiz" options={{ headerShown: false }} />
          <Stack.Screen name="review/session" options={{ headerShown: true, title: "Révision" }} />
          <Stack.Screen name="paywall" options={{ headerShown: true, title: "Premium" }} />
          <Stack.Screen name="deck/[deckId]/cards" options={{ headerShown: false }} />
          <Stack.Screen name="deck/[deckId]/stats" options={{ headerShown: false }} />
          <Stack.Screen name="deck/[deckId]/card-editor" options={{ headerShown: true, title: "Modifier" }} />
          <Stack.Screen name="deck/[deckId]/quiz-history" options={{ headerShown: true, title: "Historique QCM" }} />
          <Stack.Screen name="onboarding/index" options={{ headerShown: false }} />
          <Stack.Screen name="auth/login" options={{ headerShown: false }} />
          <Stack.Screen name="auth/signup" options={{ headerShown: false }} />
        </Stack>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
