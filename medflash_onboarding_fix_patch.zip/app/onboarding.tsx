import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useCallback } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { useAppStore } from "../src/store/useAppStore";
import { useStitchTheme } from "../src/uiStitch/theme";

/**
 * Onboarding minimal.
 *
 * Pourquoi : sur un nouvel appareil (ex: émulateur Android), `onboardingDone` est `false`.
 * L'app redirige alors vers `/onboarding`. Si la route n'existe pas, Expo Router peut planter.
 */
export default function OnboardingScreen() {
  const t = useStitchTheme();
  const router = useRouter();
  const setOnboardingDone = useAppStore((s: any) => s.setOnboardingDone);

  const onContinue = useCallback(async () => {
    try {
      await setOnboardingDone(true);
    } catch (e) {
      console.warn("[Onboarding] setOnboardingDone failed", e);
      // On continue quand même, c'est non-bloquant.
    }
    router.replace("/(tabs)");
  }, [router, setOnboardingDone]);

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: t.bg }]} edges={["top", "left", "right"]}>
      <View style={styles.header}>
        <Text style={{ color: t.text, fontFamily: t.font.display, fontSize: 32, letterSpacing: -0.4 }}>
          Bienvenue
        </Text>
        <Text style={{ color: t.muted, fontFamily: t.font.body, fontSize: 14, lineHeight: 20, marginTop: 10 }}>
          CliniCard t’aide à réviser avec des flashcards et des QCM. Tu peux importer tes cours, puis lancer une
          session de révision en 1 clic.
        </Text>
      </View>

      <View style={[styles.card, { backgroundColor: t.card, borderColor: t.border }]}>
        <View style={styles.row}>
          <View style={[styles.icon, { backgroundColor: t.dark ? "rgba(19,127,236,0.15)" : "rgba(19,127,236,0.10)" }]}>
            <Ionicons name="library-outline" size={22} color={t.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: t.text, fontFamily: t.font.display, fontSize: 16 }}>Importe tes cours</Text>
            <Text style={{ color: t.muted, fontFamily: t.font.body, fontSize: 13, marginTop: 2 }}>
              PDFs, texte, etc. (selon ton flux actuel).
            </Text>
          </View>
        </View>

        <View style={[styles.sep, { backgroundColor: t.border }]} />

        <View style={styles.row}>
          <View style={[styles.icon, { backgroundColor: t.dark ? "rgba(249,115,22,0.18)" : "rgba(249,115,22,0.14)" }]}>
            <Ionicons name="play" size={22} color="#f97316" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: t.text, fontFamily: t.font.display, fontSize: 16 }}>Révise en session</Text>
            <Text style={{ color: t.muted, fontFamily: t.font.body, fontSize: 13, marginTop: 2 }}>
              Mode mixte : toutes les cartes dues.
            </Text>
          </View>
        </View>
      </View>

      <Pressable
        onPress={onContinue}
        style={({ pressed }) => [
          styles.primary,
          {
            backgroundColor: t.primary,
            opacity: pressed ? 0.9 : 1,
          },
        ]}
      >
        <Text style={{ color: "#fff", fontFamily: t.font.display, fontSize: 15 }}>Commencer</Text>
      </Pressable>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, paddingHorizontal: 18, justifyContent: "space-between", paddingBottom: 22 },
  header: { paddingTop: 18 },
  card: {
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 16,
    marginTop: 20,
  },
  row: { flexDirection: "row", alignItems: "center", gap: 12 },
  icon: { width: 42, height: 42, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  sep: { height: StyleSheet.hairlineWidth, marginVertical: 14 },
  primary: { height: 48, borderRadius: 16, alignItems: "center", justifyContent: "center" },
});
